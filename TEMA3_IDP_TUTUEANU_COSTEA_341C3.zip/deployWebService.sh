#!/bin/bash
export AXIS_HOME=/home/radu/axis-1_4
export AXIS_LIB=$AXIS_HOME/lib
export AXISCLASSPATH=$AXIS_LIB/axis.jar:$AXIS_LIB/commons-discovery-0.2.jar:$AXIS_LIB/commons-logging-1.0.4.jar:$AXIS_LIB/jaxrpc.jar:$AXIS_LIB/saaj.jar:$AXIS_LIB/log4j-1.2.8.jar:$AXIS_LIB/wsdl4j-1.5.1.jar
AXIS_CLASSES_PATH=/home/radu/apache-tomcat-7.0.39/webapps/axis/WEB-INF/classes
cp -r bin/webservice $AXIS_CLASSES_PATH
cp -r bin/model $AXIS_CLASSES_PATH
java -cp $AXISCLASSPATH org.apache.axis.client.AdminClient -lhttp://localhost:8080/axis/services/AdminService deploy.wsdd
